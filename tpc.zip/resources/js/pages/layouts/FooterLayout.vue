<template>
    <footer class="footer py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-sm-6">
                    <div class="footer-content mt-3">
                        <img src="@/assets/images/footer-logo.svg" alt="Biz Service">
                        <p class="mt-5">©2021 Biz Screener. All rights reserved.</p>
                        <ul class="social-media mt-3">
                            <li><a href=""><font-awesome-icon icon="twitter" /></a></li>
                            <li><a href=""><font-awesome-icon icon="facebook" /></a></li>
                            <li><a href=""><font-awesome-icon icon="instagram" /></a></li>                            
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 mt-5 mt-sm-0">
                    <div class="footer-content mt-3">
                        <h5 class="mb-4">Get in Touch</h5>
                        <p>Lafayette, CO</p>
                        <div class="mt-4">
                            <a href="mailto:hello@bizscreener.com">hello@bizscreener.com</a><br>
                            <a href="tel:720-876-1981">720-876-1981</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="footer-content mt-5 mt-lg-3">
                        <h5 class="mb-4">Learn More</h5>
                        <ul class="list">
                            <li><a href="">Home</a></li>
                            <li><a href="">About</a></li>
                            <li><a href="">Pricing</a></li>
                            <li><a href="">Calculator</a></li>
                            <li><a href="">Contact</a></li>
                            <li><a href="">Terms of Service</a></li>
                            <li><a href="">Privacy Policy</a></li>
                            <li><a href="" class="text-yellow"><font-awesome-icon icon="download" /> Chrome Extension</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="footer-content mt-5 mt-lg-3">
                        <h5 class="mb-4">Our Newsletter</h5>
                        <p>Subscribe to our newsletter to get our news & deals delivered to you.</p>
                        <a href="" class="btn theme-btn-primary">Subscribe</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</template>